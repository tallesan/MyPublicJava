import static java.lang.Integer.parseInt;

import java.util.LinkedList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

public class Main {

  public static void main(String[] args) {
    try {
      StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
          .configure("hibernate.cfg.xml").build();

      Metadata metadata = new MetadataSources(registry).getMetadataBuilder().build();
      SessionFactory sessionFactory = metadata.getSessionFactoryBuilder().build();

      Session session = sessionFactory.openSession();
      Transaction transaction = session.beginTransaction();

//      Course course = session.get(Course.class,1);
//      List<Student> list = course.getStudents();
//      System.out.println(course.getTeacher().getName());
//
//      System.out.println(list.get(1).getId());
//
//      Student student = session.get(Student.class,1);
//      System.out.println(student.getName() + " - " + student.getId());


//      // Выводим таблицу Subscriptions
//      Criteria criteria = session.createCriteria(Subscriptions.class);
//      List<Subscriptions> subscriptions = new LinkedList<Subscriptions>(criteria.list());
//      for (Subscriptions cs : subscriptions) {
//        System.out.println(cs.getId().getCourse().getName() +" - " +cs.getId().getStudent().getName() + " - " +cs.getSubscriptionsDate());
//      }
//      System.out.println("=====================================");
//      Criteria criteriaKey = session.createCriteria(KeySub.class);
//      List<PLKey> plKeys = criteriaKey.list();
//      System.out.println(plKeys.size());
//      for (PLKey pl:plKeys){
//        System.out.println(pl.getStudent().getName() + " - " + pl.getCourse().getName());
//      }
//      Выводим purchaselists
      Criteria criteriaPL = session.createCriteria(Purchaselist.class);
      List<Purchaselist> purchase = new LinkedList<Purchaselist>(criteriaPL.list());
      for (Purchaselist cs : purchase) {
        System.out.println(cs.getId().getName() +" -\t " +cs.getId().getCourse() + " -\t " +cs.getPrice() + " - \t" + cs.getDateRegistr());
      }

      transaction.commit();

      sessionFactory.close();
    } catch (Exception ex) {
      ex.printStackTrace();
    }

  }
}

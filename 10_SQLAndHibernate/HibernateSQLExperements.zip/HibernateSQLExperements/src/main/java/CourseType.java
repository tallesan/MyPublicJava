public enum CourseType {
  PROGRAMMING,
  DESIGN,
  MARKETING,
  MANAGEMENT,
  BUSINESS

}
